Importer of quotations in bc3 format.

