from . import test_bc3_import_wizard
from . import test_bc3_version
